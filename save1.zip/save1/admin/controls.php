<?php
session_start();

include 'includes/config.php';
if (isset($_POST['req_pickup'])) {

if (isset($_POST['amt'])&&isset($_POST['address'])&&isset($_POST['slot'])) {
	

	$amt = $_POST['amt'];
	$address = $_POST['address'];
	$timeslot = $_POST['slot'];
	$userid = $_SESSION['userid'];

	function random_strings($length_of_string) 
{ 
  
    // String of all alphanumeric character 
    $str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'; 
  
    // Shufle the $str_result and returns substring 
    // of specified length 
    return substr(str_shuffle($str_result),  
                       0, $length_of_string); 
} 

$pub_pass = md5(random_strings(8)); 



$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["gr_img"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["add_pub"]) && $_FILES["gr_img"]) {
    $check = getimagesize($_FILES["gr_img"]["tmp_name"]);
    if($check !== false) {
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["gr_img"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
    echo "Sorry, only JPG, JPEG & PNG files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
	$newfilename= date('dmYHis').str_replace(" ", "", basename($_FILES["gr_img"]["name"]));
    if (move_uploaded_file($_FILES["gr_img"]["tmp_name"], $target_file.$newfilename)) {
    	$imagelink = $_FILES["gr_img"]["name"].$newfilename;
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

echo $sql = "INSERT INTO `requests` (`uid`, `address`, `timeslot`, `status`, `amtrec`, `photo`) VALUES ('$userid', '$address', '$timeslot', 'pending', '$amt','$imagelink')";



if ($conn->query($sql)) {
	header("location: view_recycles.php");
}
}

else {
	echo "string";
}

}

?>