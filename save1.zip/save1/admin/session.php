<?php
session_start();
if ($_SESSION['adminid']) {
  include "includes/config.php";
  $userid = $_SESSION['adminid'];
  ?>

  <?php
}
else
{
  header("location: login.php");
}
?>