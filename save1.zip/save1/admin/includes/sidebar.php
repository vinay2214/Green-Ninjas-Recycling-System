<div class="sidebar" data-color="blue">
    <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->

    <div class="logo">
        <a href="index.php" class="simple-text logo-mini">
            GN
        </a>

        <a href="index.php" class="simple-text logo-normal">
         Green Ninjas
        </a>
        
        <div class="navbar-minimize">
          <button id="minimizeSidebar" class="btn btn-outline-white btn-icon btn-round">
              <i class="now-ui-icons text_align-center visible-on-sidebar-regular"></i>
              <i class="now-ui-icons design_bullet-list-67 visible-on-sidebar-mini"></i>
          </button>
  	    </div>
        
    </div>

    <div class="sidebar-wrapper" id="sidebar-wrapper">
        
        <div class="user">
            <div class="photo">
                <img src="https://demos.creative-tim.com/now-ui-dashboard-pro/assets/img/james.jpg" />
            </div>
            <div class="info">
                <a data-toggle="collapse" href="#collapseExample" class="collapsed">
                    <span>
                        Green Ninjas
                        <b class="caret"></b>
                    </span>
                </a>
                <div class="clearfix"></div>
                <div class="collapse" id="collapseExample">
                    <ul class="nav">
                        <li>
                            <a href="#">
                                <span class="sidebar-mini-icon">MP</span>
                                <span class="sidebar-normal">My Profile</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="sidebar-mini-icon">EP</span>
                                <span class="sidebar-normal">Edit Profile</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="sidebar-mini-icon">S</span>
                                <span class="sidebar-normal">Settings</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        
        <ul class="nav">
          

          


          
            
              
              <li  class="active" >

                  
                    <a href="index.php">
                      
                        <i class="now-ui-icons design_app"></i>
                      
                      <p>Dashboard</p>
                    </a>
                  
              </li>
              
              <li >

                  
                    <a href="view_users.php" >
                      
                        <i class="fa fa-recycle"></i>
                      
                        <p>
                         View All Users</b>
                        </p>
                    </a>
                  </li>


                      <li >

                  
                    <a  href="view_recycles.php" >
                      
                        <i class="fa fa-list"></i>
                      
                        <p>
                         View Recycles</b>
                        </p>
                    </a>
                  </li>
                   <li >

                  
                    <a  href="view_valets.php" >
                      
                        <i class="fa fa-list"></i>
                      
                        <p>
                         View Valets</b>
                        </p>
                    </a>
                  </li>

                  <li >

                  
                    <a  href="add_valet.php" >
                      
                        <i class="fa fa-list"></i>
                      
                        <p>
                         Add Valet</b>
                        </p>
                    </a>
                  </li>

<li>       <a  href="add_reward.php" >
                      
                        <i class="fa fa-cart-plus"></i>
                      
                        <p>
                         Add Reward</b>
                        </p>
                    </a>
                  </li>

                  <li>       <a  href="rewards.php" >
                      
                        <i class="fa fa-gift"></i>
                      
                        <p>
                         View Reward</b>
                        </p>
                    </a>
                  </li>

                  <li>       <a  href="orders.php" >
                      
                        <i class="fa fa-gift"></i>
                      
                        <p>
                         Orders </b>
                        </p>
                    </a>
                  </li>



                     
        </ul>
    </div
></div>