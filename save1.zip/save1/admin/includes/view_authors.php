<!--

=========================================================
* Now UI Dashboard PRO - v1.5.0
=========================================================

* Product Page: https://www.creative-tim.com/product/now-ui-dashboard-pro
* Copyright 2019 Creative Tim (http://www.creative-tim.com)

* Designed by www.invisionapp.com Coded by www.creative-tim.com

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

-->

<!DOCTYPE html>
<html lang="en">

<?php
include 'includes/header.php';
?>

    <body class=" sidebar-mini ">
      
      <!-- Google Tag Manager (noscript) -->

<!-- End Google Tag Manager (noscript) -->

      

        

        <div class="wrapper ">
          
            <?php
            include 'includes/sidebar.php';
            ?>


            <div class="main-panel" id="main-panel">
              <!-- Navbar -->
<?php
include 'includes/nav.php';
?>
<!-- End Navbar -->


              

                  <div class="panel-header panel-header-md">
  
  
  
</div>


                  <div class="content">

                    <div class="row">
<div class="col-md-12">
            















<div class="card">
    <div class="card-header">
        <h4 class="card-title"> View All Publishers</h4>
        
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table">
                <thead class="text-primary">
                    
<tr><th class="text-center">
    
        #
    
</th>

<th>
    
        Name
    
</th>

<th>
    
        Email
    
</th>

<th class="text-center">
    
        Total Books
    
</th>

<th class="text-right">
    
        Royalty Earned
    
</th>




                </tr></thead>
                <tbody>
                    
                        
    

    
        
            <tr>
                
                    
                        
                        
                        <td class="text-center">
                            
                                1
                            
                        </td>
                    
                
                    
                        
                        
                        <td>
                            
                                Aamir Khan
                            
                        </td>
                    
                
                    
                        
                        
                        <td>
                            
                               fanatixx@gmail.com
                            
                        </td>
                    
                
                    
                        
                        
                        <td class="text-center">
                            
                                352
                        </td>
                    
                
                    
                        
                        
                        <td class="text-right">
                            
                                12,985
                            
                        </td>
                    
                

                
                    <td class="text-right">
                    
                        
                        
<button type="button" rel="tooltip" class="btn btn-success btn-icon btn-sm " data-original-title="" title="">
    

    
        <i class="fa fa-eye"></i>
    
</button>

                    
                        
                        <button type="button" rel="tooltip" class="btn btn-success btn-icon btn-sm " data-original-title="" title="">
    

    
        <i class="now-ui-icons text_caps-small"></i>
    
</button>

                    
                        
                        <button type="button" rel="tooltip" class="btn btn-danger btn-icon btn-sm " data-original-title="" title="">
    

    
        <i class="now-ui-icons ui-1_simple-remove"></i>
    
</button>

                    
                    </td>
                
            </tr>
     
                </tbody>
            </table>
        </div>
    </div>
</div>

        </div>
                    </div>


  </div>
  <?php
                 include 'includes/footer.php';
                 ?>
</div>

                  </div>
<?php 
include "includes/js.php";
?>
    </body>

</html>
