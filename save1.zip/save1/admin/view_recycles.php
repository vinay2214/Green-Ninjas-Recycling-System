<?php
session_start();
include "includes/config.php";
if ($_SESSION['userid']) {
  $userid = $_SESSION['userid'];
$sql = "SELECT * FROM requests";

?><!DOCTYPE html>
<html lang="en">

<?php
include 'includes/header.php';
?>

    <body class=" sidebar-mini ">
      
      <!-- Google Tag Manager (noscript) -->

<!-- End Google Tag Manager (noscript) -->

      

        

        <div class="wrapper ">
          
            <?php
            include 'includes/sidebar.php';
            ?>


            <div class="main-panel" id="main-panel">
              <!-- Navbar -->
<?php
include 'includes/nav.php';
?>
<!-- End Navbar -->


              

                  <div class="panel-header panel-header-md">
  
  
  
</div>

<div class="content">
                          <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">All Recycles</h4>
                </div>
                <div class="card-body">

                    <div class="toolbar">
                        <!--        Here you can write extra buttons/actions for the toolbar              -->
                    </div>
                    <table id="datatable" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>
    
        ID
    
</th>

<th>
    
        Status
    
</th>

<th >
    
        Time Slot
    
</th>

<th >
    
        Address
    
</th>
<th>
    
        Valet Alloted
    
</th>
<th >
    
        Action
    
</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>
    
        ID
    
</th>

<th>
    
        Status
    
</th>

<th >
    
        Time Slot
    
</th>

<th>
    
        Address
    
</th>
<th>
    
        Valet Alloted
    
</th>
<th>
    
        Action
    
</th>
                            </tr>
                        </tfoot>
                        <tbody>
                          <?php
                          if ($result = $conn -> query($sql)){
                          while ($row = $result->fetch_row()) {
                          ?>
                            <tr>
                                <td><?php echo $row['0']?></td>
                                <td><?php echo $row['4']?></td>
                                <td><?php echo $row['3']?></td>
                                <td><?php echo $row['2']?></td>
                                <td>Hemant Singh</td>
                                <td class="">
                                    <a href="detail_rec.php?id=<?php echo $row['0']?>" class="btn btn-round btn-info btn-icon btn-sm like"><i class="fas fa-eye"></i></a>
                                    <a href="?delete=<?php echo $row['0']?>" class="btn btn-round btn-danger btn-icon btn-sm remove"><i class="fas fa-times"></i></a>
                                </td>
                               
                            </tr>
                            <?php
                          }
                        }
                          ?>



                            
                            
                        </tbody>
                    </table>
                </div><!-- end content-->
            </div><!--  end card  -->
        </div> <!-- end col-md-12 -->
    </div> <!-- end row -->

                  </div>
  <?php
                 include 'includes/footer.php';
                 ?>
</div>

                  </div>
<?php 
include "includes/js.php";
?>
<script>
  $(document).ready(function() {
    $('#datatable').DataTable({
      "pagingType": "full_numbers",
      "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
      responsive: true,
      language: {
      search: "_INPUT_",
      searchPlaceholder: "Search records",
      }

    });

    var table = $('#datatable').DataTable();

    // Edit record
    table.on( 'click', '.edit', function () {
      $tr = $(this).closest('tr');
      if($($tr).hasClass('child')){
        $tr = $tr.prev('.parent');
      }

      var data = table.row($tr).data();
      alert( 'You press on Row: ' + data[0] + ' ' + data[1] + ' ' + data[2] + '\'s row.' );
    } );

    // Delete a record
    table.on( 'click', '.remove', function (e) {
      $tr = $(this).closest('tr');
      if($($tr).hasClass('child')){
        $tr = $tr.prev('.parent');
      }
      table.row($tr).remove().draw();
      e.preventDefault();
    } );

    //Like record
   
  });
</script>
    </body>

</html>
<?php }
else {
  header("location :login.php");
} ?>