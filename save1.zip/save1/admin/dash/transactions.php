<?php
session_start();
if (isset($_SESSION['username'])) {
include('code/config.php');
$mail = $_SESSION['username']; 

$UserData1 = mysqli_query($conn,"select * from authors where auth_mail='$mail'");
$UserData = mysqli_fetch_array($UserData1);
$SelectTxn = mysqli_query($conn,"select * from transactions where t_auth='$mail' order by tid desc");

?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Transactions | FanatixX.in</title>
  <!-- Favicon -->
  <link href="./assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
  <link href="./assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
  <!-- Argon CSS -->
  <link type="text/css" href="./assets/css/argon.css?v=1.0.0" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.min.js"></script>

  <script src="utils.js"></script>
</head>

<body>
  <!-- Sidenav -->
<?php include('assets/nav.php');
?>
  <!-- Main content -->
  <div class="main-content">
    <!-- Top navbar -->
    <nav class="navbar navbar-top navbar-expand-md navbar-dark" id="navbar-main">
      <div class="container-fluid">
        <!-- Brand -->
        <a class="h4 mb-0 text-white text-uppercase d-none d-lg-inline-block" href="index.php">Dashboard</a>
        <!-- Form -->
        <form class="navbar-search navbar-search-dark form-inline mr-3 d-none d-md-flex ml-lg-auto">
          <div class="form-group mb-0">
            <div class="input-group input-group-alternative">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-search"></i></span>
              </div>
              <input class="form-control" placeholder="Search" type="text">
            </div>
          </div>
        </form>
        <!-- User -->
        <ul class="navbar-nav align-items-center d-none d-md-flex">
          <li class="nav-item dropdown">
            <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <div class="media align-items-center">
                <span class="avatar avatar-sm rounded-circle">
                  <img alt="Image placeholder" src="https://image.flaticon.com/icons/svg/145/145848.svg">
                </span>
                <div class="media-body ml-2 d-none d-lg-block">
                  <span class="mb-0 text-sm  font-weight-bold"><?php echo $UserData['1']; ?></span>
                </div>
              </div>
            </a>
            <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
              <div class=" dropdown-header noti-title">
                <h6 class="text-overflow m-0">Welcome!</h6>
              </div>
              <a href="profile.php" class="dropdown-item">
                <i class="ni ni-single-02"></i>
                <span>My profile</span>
              </a>
              <div class="dropdown-divider"></div>
              <a href="logout.php" class="dropdown-item">
                <i class="ni ni-user-run"></i>
                <span>Logout</span>
              </a>
            </div>
          </li>
        </ul>
      </div>    </nav>
    <!-- Header -->
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
      
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--7">
      
      <div class="row mt-5">
        <div class="col-xl-12 mb-5 mb-xl-0">
<div class="card shadow">
            <div class="card-header border-0">
              <h3 class="mb-0">Recent Transactions</h3>
            </div>

            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">Book</th>
                    <th scope="col">Name</th>
                    <th scope="col">Royalty</th>
                    <th scope="col">Payment Status</th>
                    <th scope="col">TXN Date</th>
                    <th scope="col">Returned Books</th>
                    <th scope="col">Return Amount</th>
                    <th scope="col">Total Books Sold</th>
                    <th scope="col">More</th>
                  </tr>
                </thead>
                <tbody>

                  <?php

                  $sr = 0;
                
                  while ($SelectTxn1 = mysqli_fetch_assoc($SelectTxn)) {
                            $BookId = $SelectTxn1['t_bookid'];
                            $BookData = mysqli_query($conn,"select * from books where book_id='$BookId'");
                            $BookData1 = mysqli_fetch_assoc($BookData);
                  

                  ?>
                    <tr>
                    <th scope="row">
                      <div class="media align-items-center">
                        <a href="#" class="avatar rounded-circle mr-3">
                          <img alt="Image placeholder" src="https://png.clipart.me/istock/previews/3674/36743432-book-vector-icon.jpg">
                        </a>
                        <div class="media-body">
                          <span class="mb-0 text-sm"></span>
                        </div>
                      </div>
                    </th>
                    <td>
                    <?php
                      echo $BookData1['book_name'];
                     ?>                    
                   </td>
                                        
                    <td>
                      <?php
                      echo $SelectTxn1['t_amt'];
                     ?>
                    </td>
                    <td>
                       <?php 
                         if ($SelectTxn1['t_status']=="unpaid") {
                         
                         ?>
                      <span class="badge badge-dot mr-4">
                        <i class="bg-warning"></i> Pending
                      </span><?php 
                      }
                      else {

                        ?><span class="badge badge-dot mr-4">
                        <i class="bg-success"></i> Paid
                      </span>
                    <?php }?>
                  </td>
                    <td>
                     <?php 
                     $s = $SelectTxn1['t_time'];
                     list($s) = explode(' ',$s);
                     echo $s;
                     ?>
                    </td>
                    <td>
                      <?php
                      echo $SelectTxn1['t_rtnqty'];
                     ?>
                    </td>
                    <td>
                      <?php
                      echo $SelectTxn1['t_rtnamt'];
                     ?>
                    </td>
                    <td>
                      <?php
                      echo $SelectTxn1['t_book'];
                     ?>
                    </td>
                    <td><!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal<?php echo $sr; ?>">
More</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal<?php echo $sr; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"> <?php
                      echo $BookData1['book_name'];
                     ?> </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
      <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">Amazon Sales</th>
                    <th scope="col">Royalty</th>
                    <th scope="col">Kindle Sales</th>
                    <th scope="col">Royalty</th>
                    <th scope="col">FanatixX Sales</th>
                    <th scope="col">Royalty</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
      
                    <td>
                      <?php
                      echo $SelectTxn1['t_asales'];
                     ?>
                    </td>
                    <td>
                      <?php
                      echo $SelectTxn1['t_aroyalty'];
                     ?>
                    </td>
                    <td>
                      <?php
                      echo $SelectTxn1['t_ksales'];
                     ?>
                    </td>
                    <td>
                      <?php
                      echo $SelectTxn1['t_kroyalty'];
                     ?>
                    </td>
                    <td>
                      <?php
                      echo $SelectTxn1['t_dsales'];
                     ?>
                    </td>
                    <td>
                      <?php
                      echo $SelectTxn1['t_droyalty'];
                     ?>
                    </td>
                  </tr></tbody></table>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
                      
                    </td>
                    
                  </tr>
                <?php 
              $sr++;
            }
                 ?>
                </tbody>
              </table>
            </div>
            <div class="card-footer py-4">

            </div>
          </div>
        </div>

      </div>
      <!-- Footer -->

<?php 
include('assets/footer.php');
?>
    </div>
  </div>
  <!-- Argon Scripts -->
  <!-- Core -->
  <script src="./assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="./assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Optional JS -->
  <script src="./assets/vendor/chart.js/dist/Chart.min.js"></script>
  <script src="./assets/vendor/chart.js/dist/Chart.extension.js"></script>
  <!-- Argon JS -->
  <script src="./assets/js/argon.js?v=1.0.0"></script>
</body>

</html>
<?php

  }
  else {

    header("Location: login.php");
  }

?>