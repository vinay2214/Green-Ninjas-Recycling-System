<?php
// Always start this first
session_start();

// Destroying the session clears the $_SESSION variable, thus "logging" the user
// out. This also happens automatically when the browser is closed
session_destroy();
setcookie("username", '', time() - 3600, "/");
setcookie("password", '', time() - 3600, "/");
header("Location: login.php");
?>