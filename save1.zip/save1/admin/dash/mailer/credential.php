<?php 
	/*Update credentials*/
	define('EMAIL', 'aamir@fanatixx.in');
	define('PASS', 'Afkhan@145');
 ?>