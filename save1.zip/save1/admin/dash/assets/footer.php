      <footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
            <div class="copyright text-center text-xl-left text-muted">
            
              <a href="https://fanatixx.in" class="nav-link" target="_blank">Green Ninjas</a>

            </div>
          </div>
          <div class="col-xl-6">
            <ul class="nav nav-footer justify-content-center justify-content-xl-end">
              
              <li class="nav-item">
                <a href="https://facebook.com/afkhanxD" class="nav-link" target="_blank">Developed by Team Fix-It!</a>
              </li>
              <li class="nav-item">
                <a href="https://fanatixx.in/#!/about" class="nav-link" target="_blank">Rewards</a>
              </li>
              <li class="nav-item">
                <a href="http://shop.fanatixx.in" class="nav-link" target="_blank">Green Points</a>
              </li>
            </ul>
          </div>
        </div>
      </footer>